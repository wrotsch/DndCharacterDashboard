package csi203.f18;

import javax.swing.*;
import java.awt.*;
public class WeaponsAndDicePanel extends JPanel{

	WeaponsPanel weapons = new WeaponsPanel();
	DicePanel dice = new DicePanel();
	JButton jbtFileSave = new JButton("Save As File");
	JButton jbtFileUpload = new JButton("Upload .dnd File");
	
	public WeaponsAndDicePanel() {
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.add(weapons);
		this.add(dice);
		this.add(jbtFileSave);
		this.add(jbtFileUpload);
		
		jbtFileSave.setToolTipText("Save character sheet to a new .dnd file");
		jbtFileUpload.setToolTipText("Load a .dnd file and display the character sheet");
	}
	
}
