package csi203.f18;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
public class ArmorClassPanel extends JPanel{

	JTextArea armorClassText = new JTextArea(1,10);
	
	public ArmorClassPanel() {
		this.setBorder(new TitledBorder("ArmorClass"));
		this.add(armorClassText);
		
		armorClassText.setToolTipText("Enter your armor class rating.");
	}
}
