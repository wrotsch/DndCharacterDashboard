package csi203.f18;

import java.awt.*;
import javax.swing.*;

public class CurrentHitPointsPanel extends JPanel{
	
	JTextArea currentHitPoints = new JTextArea(2,28);
	
	public CurrentHitPointsPanel() {
		this.add(currentHitPoints);
		
		currentHitPoints.setToolTipText("Enter Current Hit Points here (ex. 12)");
	}
}
