package csi203.f18;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

public class InspirationPanel extends JPanel {
	
	JTextField inspirationText = new JTextField(5);
	JTextField proficiencyBonusText = new JTextField(5);
	
	JLabel inspirationLabel = new JLabel("Inspiration");
	JLabel proficiencyBonusLabel = new JLabel("Proficiency Bonus");
	
	public InspirationPanel() {
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.add(inspirationLabel);
		this.add(inspirationText);
		this.add(proficiencyBonusLabel);
		this.add(proficiencyBonusText);
		
		inspirationText.setToolTipText("Enter Inspiration value");
		proficiencyBonusText.setToolTipText("Enter Proficiency Bonus (ex. +3)");
	}
}
