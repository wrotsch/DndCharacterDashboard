package csi203.f18;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.*;
import javax.swing.border.*;

public class HitDicePanel extends JPanel{

	JLabel totalHitDiceLabel = new JLabel("Total");
	JLabel dice = new JLabel("Dice Type");
	
	JTextField totalHitDiceText = new JTextField(10);
	JTextField diceType = new JTextField(2);
	
	JButton jbtHitDiceRoll = new JButton("Roll Hit Dice");
	JPanel blank = new JPanel();
	
	public HitDicePanel() {
		this.setLayout(new GridLayout(3,2));
		this.add(totalHitDiceLabel);
		this.add(totalHitDiceText);
		this.add(dice);
		this.add(diceType);
		this.setBorder(new TitledBorder("Hit Dice"));
		this.add(blank);
		this.add(jbtHitDiceRoll);
		
		totalHitDiceText.setToolTipText("Enter Hit Dice Type here (ex. d10");
		diceType.setToolTipText("Enter Number of Hit Dice here (ex. 2)");
		jbtHitDiceRoll.setToolTipText("Roll Hit Dice");
		
	}
}
