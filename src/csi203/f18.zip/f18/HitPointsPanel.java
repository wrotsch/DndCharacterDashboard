package csi203.f18;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class HitPointsPanel extends JPanel{

	CurrentHitPointsPanel currentHitPoints = new CurrentHitPointsPanel();
	HitPointMaximumPanel hitPointMaximum = new HitPointMaximumPanel();
	TemporaryHitPointsPanel temporaryHitPoints = new TemporaryHitPointsPanel();
	
	public HitPointsPanel() {
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.add(hitPointMaximum);
		currentHitPoints.setPreferredSize(new Dimension(8,28));
		this.add(currentHitPoints);
		this.add(temporaryHitPoints);
		this.setBorder(new TitledBorder("Hit Points"));
	}
}
