package csi203.f18;

import java.awt.*;
import javax.swing.*;

public class StatsPanelRight extends JPanel{
	
	SkillsPanel skills = new SkillsPanel();
	SavingThrowsModPanel savingThrows = new SavingThrowsModPanel();
	
	public StatsPanelRight() {
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

		this.add(savingThrows);
		this.add(skills);
	}
}
