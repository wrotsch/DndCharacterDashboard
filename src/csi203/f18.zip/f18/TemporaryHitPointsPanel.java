package csi203.f18;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
public class TemporaryHitPointsPanel extends JPanel{
	
	JTextField temporaryHitPoints = new JTextField(10);
	
	public TemporaryHitPointsPanel() {
		this.add(temporaryHitPoints);
		this.setBorder(new TitledBorder("Temporary Hit Points"));
		
		temporaryHitPoints.setToolTipText("Enter Temporary Hit Points here");
	}
}
