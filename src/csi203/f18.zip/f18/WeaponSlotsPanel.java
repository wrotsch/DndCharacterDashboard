package csi203.f18;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.util.Random;
import java.util.Scanner;
public class WeaponSlotsPanel extends JPanel{

	JLabel weaponNameLabel = new JLabel("Name");
	JLabel attackBonusLabel = new JLabel("ATK Bonus");
	JLabel damageLabel = new JLabel("Damage");
	
	JTextField weaponName1 = new JTextField();
	JTextField weaponAttack1 = new JTextField();
	JTextField weaponDamage1 = new JTextField();
	
	JTextField weaponName2 = new JTextField();
	JTextField weaponAttack2 = new JTextField();
	JTextField weaponDamage2 = new JTextField();
	
	JTextField weaponName3 = new JTextField();
	JTextField weaponAttack3 = new JTextField();
	JTextField weaponDamage3 = new JTextField();
	JPanel blank = new JPanel();
	
	JButton jbtWeapon1 = new JButton("Use");
	JButton jbtWeapon2 = new JButton("Use");
	JButton jbtWeapon3 = new JButton("Use");
	
	Random rand = new Random();
	
	public WeaponSlotsPanel() {
		this.setLayout(new GridLayout(4,4));
		this.add(weaponNameLabel);
		this.add(attackBonusLabel);
		this.add(damageLabel);
		this.add(blank);
		this.add(weaponName1);
		this.add(weaponAttack1);
		this.add(weaponDamage1);
		this.add(jbtWeapon1);
		this.add(weaponName2);
		this.add(weaponAttack2);
		this.add(weaponDamage2);
		this.add(jbtWeapon2);
		this.add(weaponName3);
		this.add(weaponAttack3);
		this.add(weaponDamage3);
		this.add(jbtWeapon3);
		this.setBorder(new TitledBorder("Weapons"));
		
		weaponName1.setToolTipText("Enter the name of your first weapon");
		weaponAttack1.setToolTipText("Enter the attack bonus of your first weapon (ex. +5)");
		weaponDamage1.setToolTipText("Enter the damage dice for your first weapon (ex. 2d8");
		jbtWeapon1.setToolTipText("Use your first weapon.");
		weaponName2.setToolTipText("Enter the name of your second weapon");
		weaponAttack2.setToolTipText("Enter the attack bonus of your second weapon (ex. +5)");
		weaponDamage2.setToolTipText("Enter the damage dice for your second weapon (ex. 2d8)");
		jbtWeapon2.setToolTipText("Use your second weapon.");
		weaponName3.setToolTipText("Enter the name of your third weapon");
		weaponAttack3.setToolTipText("Enter the attack bonus of your third weapon (ex. +5)");
		weaponDamage3.setToolTipText("Enter the damage dice for your third weapon (ex. 2d8)");
		jbtWeapon3.setToolTipText("Use your third weapon");
		
		jbtWeapon1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String diceType = weaponDamage1.getText();
				int diceNum = diceType.charAt(0)- '0';
				diceType = diceType.substring(1);
				int attackMod = Integer.parseInt(weaponAttack1.getText());
				int damage = 0;
				
				if(diceType.equals("d20")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(20)+1;
					}
					damage+=Integer.parseInt(weaponAttack1.getText());
				}
				
				else if(diceType.equals("d12")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(12)+1;
					}
					damage+=Integer.parseInt(weaponAttack1.getText());
				}
				
				else if(diceType.equals("d10")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(10)+1;
					}
					damage+=Integer.parseInt(weaponAttack1.getText());
				}
				
				else if(diceType.equals("d8")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(8)+1;
					}
					damage+=Integer.parseInt(weaponAttack1.getText());
				}
				
				else if(diceType.equals("d6")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(6)+1;
					}
					damage+=Integer.parseInt(weaponAttack1.getText());
				}
				
				else if(diceType.equals("d4")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(4)+1;
					}
					damage+=Integer.parseInt(weaponAttack1.getText());
				}
				
				JOptionPane.showMessageDialog(null, "You have dealt " + damage + " points of damage with " + weaponName1.getText() + ".");
			}
		});
		
		jbtWeapon2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String diceType = weaponDamage2.getText();
				int diceNum = diceType.charAt(0)- '0';
				diceType = diceType.substring(1);
				int attackMod = Integer.parseInt(weaponAttack2.getText());
				int damage = 0;
				
				if(diceType.equals("d20")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(20)+1;
					}
					damage+=Integer.parseInt(weaponAttack2.getText());
				}
				
				else if(diceType.equals("d12")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(12)+1;
					}
					damage+=Integer.parseInt(weaponAttack2.getText());
				}
				
				else if(diceType.equals("d10")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(10)+1;
					}
					damage+=Integer.parseInt(weaponAttack2.getText());
				}
				
				else if(diceType.equals("d8")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(8)+1;
					}
					damage+=Integer.parseInt(weaponAttack2.getText());
				}
				
				else if(diceType.equals("d6")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(6)+1;
					}
					damage+=Integer.parseInt(weaponAttack2.getText());
				}
				
				else if(diceType.equals("d4")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(4)+1;
					}
					damage+=Integer.parseInt(weaponAttack2.getText());
				}
				
				JOptionPane.showMessageDialog(null, "You have dealt " + damage + " points of damage with " + weaponName2.getText() + ".");
			}
		});
		
		jbtWeapon3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String diceType = weaponDamage3.getText();
				int diceNum = diceType.charAt(0)- '0';
				diceType = diceType.substring(1);
				int attackMod = Integer.parseInt(weaponAttack3.getText());
				int damage = 0;
				
				if(diceType.equals("d20")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(20)+1;
					}
					damage+=Integer.parseInt(weaponAttack3.getText());
				}
				
				else if(diceType.equals("d12")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(12)+1;
					}
					damage+=Integer.parseInt(weaponAttack3.getText());
				}
				
				else if(diceType.equals("d10")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(10)+1;
					}
					damage+=Integer.parseInt(weaponAttack3.getText());
				}
				
				else if(diceType.equals("d8")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(8)+1;
					}
					damage+=Integer.parseInt(weaponAttack3.getText());
				}
				
				else if(diceType.equals("d6")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(6)+1;
					}
					damage+=Integer.parseInt(weaponAttack3.getText());
				}
				
				else if(diceType.equals("d4")) {
					for(int i =0; i<diceNum; i++){
						damage+=rand.nextInt(4)+1;
					}
					damage+=Integer.parseInt(weaponAttack3.getText());
				}
				
				JOptionPane.showMessageDialog(null, "You have dealt " + damage + " points of damage with " + weaponName3.getText() + ".");
			}
		});
	}
}
