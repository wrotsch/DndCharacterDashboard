package csi203.f18;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class ProficienciesPanel extends JPanel {

	JTextArea proficiencies = new JTextArea(6,28);
	
	public ProficienciesPanel() {
		this.add(proficiencies);
		this.setBorder(new TitledBorder("Other Proficiencies and Languages"));
		
		proficiencies.setToolTipText("Enter your character's languages, proficiences or any other facts");
	}
}
