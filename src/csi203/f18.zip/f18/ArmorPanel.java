package csi203.f18;

import java.awt.*;
import javax.swing.*;

public class ArmorPanel extends JPanel{

	JTextField armor = new JTextField(10);
	JTextField ac = new JTextField(3);
	
	JLabel armorLabel = new JLabel("Armor");
	JLabel acLabel = new JLabel("AC");
	
	JRadioButton shield = new JRadioButton("Shield");
	
	public ArmorPanel() {
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.add(armorLabel);
		this.add(armor);
		this.add(shield);
		this.add(acLabel);
		this.add(ac);
		
		armor.setToolTipText("Enter your character's armor here");
		shield.setToolTipText("Does your character have a shield?");
		ac.setToolTipText("Set the Armor class given by this set of armor.");
		
	}
	
}
