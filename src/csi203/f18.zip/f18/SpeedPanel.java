package csi203.f18;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class SpeedPanel extends JPanel{

	JTextArea speedText = new JTextArea(1,10);
	
	public SpeedPanel() {
		this.setBorder(new TitledBorder("Speed"));
		this.add(speedText);
		
		speedText.setToolTipText("Enter your base moving speed here.");
	}
}
