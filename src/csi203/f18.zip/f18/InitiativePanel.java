package csi203.f18;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class InitiativePanel extends JPanel{

	JTextArea initiativeText = new JTextArea(1,10);
	
	public InitiativePanel() {
		this.setBorder(new TitledBorder("Initiative"));
		this.add(initiativeText);
		
		initiativeText.setToolTipText("Enter your initiative Bonus here. It is usually equal to your Dexterity Modifier.");
	}
}
