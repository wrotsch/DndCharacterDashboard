package csi203.f18;

import java.awt.*;
import javax.swing.*;
import java.net.*;

public class BottomPanel extends JPanel {
	
	ProficienciesPanel proficiencies = new ProficienciesPanel();
	EquipmentPanel equipment = new EquipmentPanel();
	
	public BottomPanel() {
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.add(proficiencies);
		this.add(equipment);
		
	}
}
