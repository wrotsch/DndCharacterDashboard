package csi203.f18;

import java.awt.*;
import javax.swing.*;

public class WeaponsPanel extends JPanel{

	WeaponSlotsPanel weapons = new WeaponSlotsPanel();
	
	public WeaponsPanel() {
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.add(weapons);
	}
	
}
