package csi203.f18;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Random;

import javax.swing.*;

public class DashboardFrame extends JFrame implements java.io.Serializable{
	StatsPanel stats = new StatsPanel();
	BiographyPanel bio = new BiographyPanel();
	BottomPanel bottom = new BottomPanel();
	CombatPanel combat = new CombatPanel();
	WeaponsAndDicePanel wAndD = new WeaponsAndDicePanel();
	Random rand = new Random();
	
	public DashboardFrame() {
		
		add(stats, BorderLayout.WEST);
		add(bio, BorderLayout.NORTH);
		add(bottom, BorderLayout.SOUTH);
		add(combat, BorderLayout.CENTER);
		add(wAndD, BorderLayout.EAST);
		
		DashboardFrame frame = this;
		
		combat.bottom.hitDice.jbtHitDiceRoll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String hitDiceString;
				hitDiceString = JOptionPane.showInputDialog("How many Hit Dice would you like to use?:");
				String hitDiceType = combat.bottom.hitDice.diceType.getText();
				int healthBoost = 0;
				if((Integer.parseInt(combat.bottom.hitDice.totalHitDiceText.getText())-Integer.parseInt(hitDiceString)) < 0)
					JOptionPane.showMessageDialog(null, "You have cannot use that many hit dice.");
				else {
					for(int i =0; i < Integer.parseInt(hitDiceString); i++) {
						if(hitDiceType.equals("d20"))
							healthBoost += rand.nextInt(20)+1;
						else if(hitDiceType.equals("d12"))
							healthBoost += rand.nextInt(12)+1;
						else if(hitDiceType.equals("d10"))
							healthBoost += rand.nextInt(10)+1;
						else if(hitDiceType.equals("d8"))
							healthBoost += rand.nextInt(8)+1;
						else if(hitDiceType.equals("d6"))
							healthBoost += rand.nextInt(6)+1;
						else if(hitDiceType.equals("d4"))
							healthBoost += rand.nextInt(4)+1;
						combat.bottom.hitDice.totalHitDiceText.setText(Integer.toString(Integer.parseInt(combat.bottom.hitDice.totalHitDiceText.getText())-1));
					}
					
					int currentHitPointsInt = Integer.parseInt(combat.hitpoints.currentHitPoints.currentHitPoints.getText());
					currentHitPointsInt += healthBoost;
					if(currentHitPointsInt > Integer.parseInt(combat.hitpoints.hitPointMaximum.hitPointMaximumText.getText()))
						currentHitPointsInt = Integer.parseInt(combat.hitpoints.hitPointMaximum.hitPointMaximumText.getText());
					combat.hitpoints.currentHitPoints.currentHitPoints.setText(Integer.toString(currentHitPointsInt));
					
					JOptionPane.showMessageDialog(null, "Your Hit Points have been increased by " + healthBoost + " points by your Hit Dice Roll.");
				}	
			}
		});
		
		wAndD.jbtFileSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DndFile file = new DndFile(frame);
				String fileName = JOptionPane.showInputDialog(null, "Enter desired name of .dnd File (omit .dnd suffix)");
				fileName += ".dnd";
				file.createFile(fileName);
				
			}
		});
		
		wAndD.jbtFileUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fileName = JOptionPane.showInputDialog(null, "Enter the name of the .dnd file you want to load");
				DndFile file = new DndFile();
				FileInputStream ifstream;
				try {
					ifstream = new FileInputStream(fileName);
					ObjectInputStream in = new ObjectInputStream(ifstream);
					file = (DndFile)in.readObject();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				catch (ClassNotFoundException e2) {
					e2.printStackTrace();
				}
				
				//JOptionPane.showMessageDialog(null, file.);
		
				frame.stats.genStats.strengthField.setText(file.strengthField);
				frame.stats.genStats.strengthAdv.setText(file.strengthAdv);
				frame.stats.genStats.dexterityField.setText(file.dexterityField);
				frame.stats.genStats.dexterityAdv.setText(file.dexterityAdv);
				frame.stats.genStats.constitutionField.setText(file.constitutionField);
				frame.stats.genStats.constitutionAdv.setText(file.constitutionAdv);
				frame.stats.genStats.intelligenceField.setText(file.intelligenceField);
				frame.stats.genStats.intelligenceAdv.setText(file.intelligenceAdv);
				frame.stats.genStats.wisdomField.setText(file.wisdomField);
				frame.stats.genStats.wisdomAdv.setText(file.wisdomAdv);
				frame.stats.genStats.charismaField.setText(file.charismaField);
				frame.stats.genStats.charismaAdv.setText(file.charismaAdv);
				frame.stats.genStats.inspiration.inspirationText.setText(file.inpsirationText);
				frame.stats.genStats.inspiration.proficiencyBonusText.setText(file.proficiencyBonusText);
				frame.stats.rightStats.skills.acrobaticsText.setText(file.acrobaticsText);
				frame.stats.rightStats.skills.acrobaticsButton.setSelected(file.acrobaticsButton);
				frame.stats.rightStats.skills.animalHandlingText.setText(file.animalHandlingText);
				frame.stats.rightStats.skills.animalHandlingButton.setSelected(file.animalHandlingButton);
				frame.stats.rightStats.skills.arcanaText.setText(file.arcanaText);
				frame.stats.rightStats.skills.arcanaButton.setSelected(file.arcanaButton);
				frame.stats.rightStats.skills.athleticsText.setText(file.athleticsText);
				frame.stats.rightStats.skills.athleticsButton.setSelected(file.athleticsButton);
				frame.stats.rightStats.skills.deceptionText.setText(file.deceptionText);
				frame.stats.rightStats.skills.deceptionButton.setSelected(file.deceptionButton);
				frame.stats.rightStats.skills.historyText.setText(file.historyText);
				frame.stats.rightStats.skills.historyButton.setSelected(file.historyButton);
				frame.stats.rightStats.skills.insightText.setText(file.insightText);
				frame.stats.rightStats.skills.insightButton.setSelected(file.insightButton);
				frame.stats.rightStats.skills.intimidationText.setText(file.intimidationText);
				frame.stats.rightStats.skills.intimidationButton.setSelected(file.intimidationButton);
				frame.stats.rightStats.skills.investigationText.setText(file.investigationText);
				frame.stats.rightStats.skills.investigationButton.setSelected(file.investigationButton);
				frame.stats.rightStats.skills.medicineText.setText(file.medicineText);
				frame.stats.rightStats.skills.medicineButton.setSelected(file.medicineButton);
				frame.stats.rightStats.skills.natureText.setText(file.natureText);
				frame.stats.rightStats.skills.natureButton.setSelected(file.natureButton);
				frame.stats.rightStats.skills.perceptionText.setText(file.perceptionText);
				frame.stats.rightStats.skills.perceptionButton.setSelected(file.perceptionButton);
				frame.stats.rightStats.skills.performanceText.setText(file.performanceText);
				frame.stats.rightStats.skills.performanceButton.setSelected(file.performanceButton);
				frame.stats.rightStats.skills.persuasionText.setText(file.persuasionText);
				frame.stats.rightStats.skills.persuasionButton.setSelected(file.persuasionButton);
				frame.stats.rightStats.skills.religionText.setText(file.religionText);
				frame.stats.rightStats.skills.religionButton.setSelected(file.religionButton);
				frame.stats.rightStats.skills.sleightOfHandText.setText(file.sleightOfHandText);
				frame.stats.rightStats.skills.sleightOfHandButton.setSelected(file.sleightOfHandButton);
				frame.stats.rightStats.skills.stealthText.setText(file.stealthText);
				frame.stats.rightStats.skills.stealthButton.setSelected(file.stealthButton);
				frame.stats.rightStats.skills.survivalText.setText(file.survivalText);
				frame.stats.rightStats.skills.survivalButton.setSelected(file.survivalButton);
				frame.stats.rightStats.savingThrows.strengthSaveText.setText(file.strengthSaveText);
				frame.stats.rightStats.savingThrows.jtbStrengthSaveMod.getModel().setSelected(file.strengthSaveMod);
				frame.stats.rightStats.savingThrows.dexteritySaveText.setText(file.dexteritySaveText);
				frame.stats.rightStats.savingThrows.jtbDexteritySaveMod.setSelected(file.dexteritySaveMod);
				frame.stats.rightStats.savingThrows.constitutionSaveText.setText(file.constitutionSaveText);
				frame.stats.rightStats.savingThrows.jtbConstitutionSaveMod.setSelected(file.constitutionSaveMod);
				frame.stats.rightStats.savingThrows.intelligenceSaveText.setText(file.intelligenceSaveText);
				frame.stats.rightStats.savingThrows.jtbIntelligenceSaveMod.setSelected(file.intelligenceSaveMod);
				frame.stats.rightStats.savingThrows.wisdomSaveText.setText(file.wisdomSaveText);
				frame.stats.rightStats.savingThrows.jtbWisdomSaveMod.setSelected(file.wisdomSaveMod);
				frame.stats.rightStats.savingThrows.charismaSaveText.setText(file.charismaSaveText);
				frame.stats.rightStats.savingThrows.jtbCharismaSaveMod.setSelected(file.charismaSaveMod);
				frame.bio.name.setText(file.characterName);
				frame.bio.classLevel.setText(file.characterClassLevel);
				frame.bio.race.setSelectedItem(file.characterRace);
				frame.bio.background.setSelectedItem(file.characterBackground);
				frame.bio.alignment.setSelectedItem(file.characterAlignment);
				frame.bio.playerName.setText(file.playerName);
				frame.bio.experiencePoints.setText(file.experiencePoints);
				frame.bottom.proficiencies.proficiencies.setText(file.proficiencies);
				frame.bottom.equipment.armor.armor.setText(file.armor);
				frame.bottom.equipment.armor.ac.setText(file.armorAC);
				frame.bottom.equipment.currency.copperText.setText(file.copper);
				frame.bottom.equipment.currency.silverText.setText(file.silver);
				frame.bottom.equipment.currency.copperText.setText(file.electrum);
				frame.bottom.equipment.currency.goldText.setText(file.gold);
				frame.bottom.equipment.currency.platinumText.setText(file.platinum);
				frame.bottom.equipment.equipment.setText(file.equipment);
				frame.combat.topstats.armorClass.armorClassText.setText(file.characterArmorClass);
				frame.combat.topstats.initiative.initiativeText.setText(file.initiative);
				frame.combat.topstats.speed.speedText.setText(file.speed);
				frame.combat.hitpoints.currentHitPoints.currentHitPoints.setText(file.currentHitPoints);
				frame.combat.hitpoints.hitPointMaximum.hitPointMaximumText.setText(file.hitPointMaximum);
				frame.combat.hitpoints.temporaryHitPoints.temporaryHitPoints.setText(file.temporaryHitPoints);
				frame.combat.bottom.hitDice.totalHitDiceText.setText(file.totalHitDice);
				frame.combat.bottom.hitDice.diceType.setText(file.hitDiceType);
				frame.combat.bottom.deathSaves.jrbsuccess1.setSelected(file.deathSaveSuccess1);
				frame.combat.bottom.deathSaves.jrbsuccess2.setSelected(file.deathSaveSuccess2);
				frame.combat.bottom.deathSaves.jrbsuccess3.setSelected(file.deathSaveSuccess3);
				frame.combat.bottom.deathSaves.jrbfailure1.setSelected(file.deathSaveFailure1);
				frame.combat.bottom.deathSaves.jrbfailure2.setSelected(file.deathSaveFailure2);
				frame.combat.bottom.deathSaves.jrbfailure3.setSelected(file.deathSaveFailure3);
				frame.wAndD.weapons.weapons.weaponName1.setText(file.weaponName1);
				frame.wAndD.weapons.weapons.weaponName2.setText(file.weaponName2);
				frame.wAndD.weapons.weapons.weaponName3.setText(file.weaponName3);
				frame.wAndD.weapons.weapons.weaponAttack1.setText(file.weaponAttack1);
				frame.wAndD.weapons.weapons.weaponAttack2.setText(file.weaponAttack2);
				frame.wAndD.weapons.weapons.weaponAttack3.setText(file.weaponAttack3);
				frame.wAndD.weapons.weapons.weaponDamage1.setText(file.weaponDamage1);
				frame.wAndD.weapons.weapons.weaponDamage2.setText(file.weaponDamage2);
				frame.wAndD.weapons.weapons.weaponDamage3.setText(file.weaponDamage3);
				
			}
		});
		
	}

	public static void main(String[] args) {
		DashboardFrame frame = new DashboardFrame();//create DashboardFrame instance
		frame.pack();
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setTitle("Dungeons and Dragons Dashboard");
		frame.setLocationRelativeTo(null);//set location to center of screen
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
