package csi203.f18;

import java.awt.*;
import javax.swing.*;
public class HitPointMaximumPanel extends JPanel{

	JTextArea hitPointMaximumText = new JTextArea(1, 10);
	
	JLabel hitPointMaximumLabel = new JLabel("Hit Point Maximum");
	
	public HitPointMaximumPanel(){
		
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.add(hitPointMaximumLabel);
		this.add(hitPointMaximumText);
		
		hitPointMaximumText.setToolTipText("Enter Maximum Hit Points (ex. 24)");
	}
	
}
